Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - GRD-music- ( https://freesound.org/people/GRD-music-/ )

You can find this pack online at: https://freesound.org/people/GRD-music-/packs/23395/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 414973__grd-music__classic-tr-909-kick-jdxi-4.wav
    * url: https://freesound.org/s/414973/
    * license: Creative Commons 0
  * 414972__grd-music__classic-tr-909-kick-jdxi-5.wav
    * url: https://freesound.org/s/414972/
    * license: Creative Commons 0
  * 414971__grd-music__classic-tr-909-hatopen-jdxi-5.wav
    * url: https://freesound.org/s/414971/
    * license: Creative Commons 0
  * 414970__grd-music__classic-tr-909-kick-jdxi.wav
    * url: https://freesound.org/s/414970/
    * license: Creative Commons 0
  * 414969__grd-music__classic-tr-909-kick-jdxi-2.wav
    * url: https://freesound.org/s/414969/
    * license: Creative Commons 0
  * 414968__grd-music__classic-tr-909-kick-jdxi-3.wav
    * url: https://freesound.org/s/414968/
    * license: Creative Commons 0
  * 414967__grd-music__classic-tr-909-hatclosed-jdxi-1.wav
    * url: https://freesound.org/s/414967/
    * license: Creative Commons 0
  * 414966__grd-music__classic-tr-909-hatclosed-jdxi-2.wav
    * url: https://freesound.org/s/414966/
    * license: Creative Commons 0
  * 414965__grd-music__classic-tr-909-hatclosed-jdxi-3.wav
    * url: https://freesound.org/s/414965/
    * license: Creative Commons 0
  * 414964__grd-music__classic-tr-909-hatopen-jdxi-4.wav
    * url: https://freesound.org/s/414964/
    * license: Creative Commons 0
  * 414963__grd-music__classic-tr-909-snarerev-jdxi-3.wav
    * url: https://freesound.org/s/414963/
    * license: Creative Commons 0
  * 414962__grd-music__classic-tr-909-rim-rev-jdxi-5.wav
    * url: https://freesound.org/s/414962/
    * license: Creative Commons 0
  * 414961__grd-music__classic-tr-909-snarerev-jdxi-5.wav
    * url: https://freesound.org/s/414961/
    * license: Creative Commons 0
  * 414960__grd-music__classic-tr-909-snarerev-jdxi-4.wav
    * url: https://freesound.org/s/414960/
    * license: Creative Commons 0
  * 414959__grd-music__classic-tr-909-rim-jdxi-2.wav
    * url: https://freesound.org/s/414959/
    * license: Creative Commons 0
  * 414958__grd-music__classic-tr-909-rim-jdxi-1.wav
    * url: https://freesound.org/s/414958/
    * license: Creative Commons 0
  * 414957__grd-music__classic-tr-909-rim-jdxi-4.wav
    * url: https://freesound.org/s/414957/
    * license: Creative Commons 0
  * 414956__grd-music__classic-tr-909-rim-jdxi-3.wav
    * url: https://freesound.org/s/414956/
    * license: Creative Commons 0
  * 414955__grd-music__classic-tr-909-snare-jdxi-2.wav
    * url: https://freesound.org/s/414955/
    * license: Creative Commons 0
  * 414954__grd-music__classic-tr-909-snare-jdxi-1.wav
    * url: https://freesound.org/s/414954/
    * license: Creative Commons 0
  * 414953__grd-music__classic-tr-909-cym-jdxi-4.wav
    * url: https://freesound.org/s/414953/
    * license: Creative Commons 0
  * 414952__grd-music__classic-tr-909-cym-jdxi-5.wav
    * url: https://freesound.org/s/414952/
    * license: Creative Commons 0
  * 414951__grd-music__classic-tr-909-clap-jdxi-5.wav
    * url: https://freesound.org/s/414951/
    * license: Creative Commons 0
  * 414950__grd-music__classic-tr-909-cymrev-jdxi-1.wav
    * url: https://freesound.org/s/414950/
    * license: Creative Commons 0
  * 414949__grd-music__classic-tr-909-cym-jdxi-2.wav
    * url: https://freesound.org/s/414949/
    * license: Creative Commons 0
  * 414948__grd-music__classic-tr-909-cym-jdxi-3.wav
    * url: https://freesound.org/s/414948/
    * license: Creative Commons 0
  * 414947__grd-music__classic-tr-909-claprev-jdxi-3.wav
    * url: https://freesound.org/s/414947/
    * license: Creative Commons 0
  * 414946__grd-music__classic-tr-909-clap-jdxi-1.wav
    * url: https://freesound.org/s/414946/
    * license: Creative Commons 0
  * 414945__grd-music__classic-tr-909-clap-jdxi-2.wav
    * url: https://freesound.org/s/414945/
    * license: Creative Commons 0
  * 414944__grd-music__classic-tr-909-clap-jdxi-4.wav
    * url: https://freesound.org/s/414944/
    * license: Creative Commons 0


